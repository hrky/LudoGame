/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.handlers;

import seng271.group8.ludo.events.StartGameEvent;

/**
 *
 * @author Alastairs
 */
public class StartGameHandler implements Handler<StartGameEvent> {
    
    public StartGameHandler() {
        
    }

    @Override
    public void handle(StartGameEvent evt) {
        
    }
}
