/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.model;

import java.awt.Point;

/**
 *
 * @author Alastairs
 */
public class Home extends Square{
    public Home(Grid type, Point position) {
        super(type, position);
    }
}
