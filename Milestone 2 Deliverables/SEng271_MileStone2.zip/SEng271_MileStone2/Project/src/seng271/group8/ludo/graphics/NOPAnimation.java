/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.graphics;

/**
 *
 * @author alastair
 */
public class NOPAnimation extends Animation2D {
    public NOPAnimation(LudoGraphic g, long dur) {
        super(g, dur, "linear");
    }
}
