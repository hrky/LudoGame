/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.handlers;

import seng271.group8.ludo.GameLogic;
import seng271.group8.ludo.events.GameEvent;

/**
 *
 * @author alastair
 */
public class StatusHandler extends BaseHandler<GameEvent> {
    
    public StatusHandler(GameLogic game) {
        super(game);
    }
    
    @Override
    public void handle(GameEvent evt) {
        
    }
}
