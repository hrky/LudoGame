/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.graphics;

/**
 *
 * @author alastair
 */
public abstract class AbstractAnimationBuilder implements AnimationBuilder {
    
}
