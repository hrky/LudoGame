/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.networking;

import java.util.concurrent.ArrayBlockingQueue;

/**
 *
 * @author Alastairs
 */
public class MessageProcessor implements Runnable {

    private ArrayBlockingQueue messages;
    
    public MessageProcessor() {
    
    }
    
    public void add(Message m) {
        
    }
    
    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
