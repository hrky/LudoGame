/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo;

/**
 *
 * @author Alastairs
 */
public enum Colors {
    BLUE, RED, YELLOW, GREEN
}
