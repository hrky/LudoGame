/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.graphics;

/**
 *
 * @author alastair
 */
public interface IEasing {
    public float tic(float t, float b, float c, float d);
}
