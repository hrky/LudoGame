/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.handlers;

/**
 *
 * @author alastair
 */
public interface Handler<T>  {
    public void handle(T evt);
}
