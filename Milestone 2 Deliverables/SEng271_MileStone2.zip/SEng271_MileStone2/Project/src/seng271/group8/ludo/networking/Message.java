/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package seng271.group8.ludo.networking;

import java.io.Serializable;

/**
 *
 * @author Alastairs
 */
public class Message {
    
    private MessageType type;
    
    public Message() {
        
    }
    
    public String getMessage() {
        String t = "";
        return t;
    }
    
}
